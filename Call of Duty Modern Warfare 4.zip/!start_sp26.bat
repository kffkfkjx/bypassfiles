@echo off
setlocal

cd /d "%~dp0"

net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process -FilePath '%~f0' -WorkingDirectory '%~dp0' -Verb RunAs"
    exit /b
)

set DRIVERFILE=Randgrid.sys
set DRIVERNAME=atvi-randgrid_sr_offline
set EXENAME=sp26-cod.exe

sc query %DRIVERNAME% >nul 2>&1
if %errorlevel%==0 (
	echo AC already installed as %DRIVERNAME%
    goto startgame
) else (
    goto install_ac_driver
)

:install_ac_driver
sc.exe create %DRIVERNAME% type= kernel binPath="%CD%\%DRIVERFILE%"
echo AC installed as %DRIVERNAME%
goto startgame

:startgame
echo Launching %EXENAME%...
sc start "%DRIVERNAME%" >nul 2>&1
start /wait .\sp26\%EXENAME% hdeyguxs3zaumvlgvybm2vyc
sc stop "%DRIVERNAME%" >nul 2>&1
sc.exe delete %DRIVERNAME%

timeout 1
exit
